module systemeReducteur {
}