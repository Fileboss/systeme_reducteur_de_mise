package ptut;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class test {

	public static void main(String[] args) {
		final int SYSREDUC = 30;
		final int GARANTIE = 3;
		
		
		List<Grille> ensemble = Grille.enumererGrilles(SYSREDUC);
		List<Grille> bonnesGrilles = new ArrayList<>();
		
		//System.out.println(ensemble.toString());
		//System.out.println("Nb grilles g�n�r�es : "+ensembleSave.size());
		
		TableauBooleen taboule = new TableauBooleen(ensemble.size());
		//System.out.println("grille � tester : "+ensemble.get(0));
		///ensemble.get(0).tester(ensemble, taboule, GARANTIE, bonnesGrilles);
		//ensemble.get(ensemble.size()-1).tester(ensemble, taboule, GARANTIE, bonnesGrilles);
		
		List<Grille> ensembleSave = new ArrayList<>(ensemble);
		
		
		
		System.out.println("Poucentage du tableau avant algo : "+taboule.pourcentageVrai()+" nb bonnes grilles avant algo : "+bonnesGrilles.size());
		
		
		//strat philippe couverture de base
//		int cpt = 1;
//		for (int i = 1; i <= SYSREDUC; i+=5) {
//			bonnesGrilles.add(new Grille(i, i+1, i+2, i+3, i+4));
//			cpt+=5;
//		}
//		if ((SYSREDUC % 5) != 0 ) {
//			List<Integer> reste = new ArrayList<>();
//			for (int i = cpt; i <= SYSREDUC; i++) {
//				reste.add(i);
//			}
//			bonnesGrilles.add(new Grille(reste));
//			for (Grille g : bonnesGrilles) {
//				ensemble.remove(g);
//			} 
//		}
		//Methode c�dric
		Collections.shuffle(ensemble);
		while(ensemble.size() > 0) {
			int i = 0;
			Grille gTemp = ensemble.get(0);
			ensemble.remove(0);
			float pct = 100.0F - ((float) ensemble.size() / ensembleSave.size())*100;
			System.out.println(pct + " ");
			bonnesGrilles.add(gTemp);
			while (i < ensemble.size()) {
				if (gTemp.nbNombresEnCommun(ensemble.get(i)) >= GARANTIE) {
					ensemble.remove(i);
				} else {
					i++;
				}
			}
		}
		//Jusqu'ici
		
		
		System.out.println("Fin de l'algo\nCalcul de la couverture...\n");
		
		Outils.testerPLusieursGrilles(ensembleSave, bonnesGrilles, taboule, GARANTIE);
		
		System.out.println("\nNb grilles g�n�r�es : "+ensembleSave.size());
		
		System.out.println("\nAvant opti : Pourcentage couvert "+taboule.pourcentageVrai()+" nombre de grilles gard�es : "+bonnesGrilles.size());
		
		
	}

}
